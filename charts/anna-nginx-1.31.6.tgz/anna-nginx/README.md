# Anna Nginx

![Version: 1.31.6](https://img.shields.io/badge/Version-1.31.6-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 1.31.3](https://img.shields.io/badge/AppVersion-1.31.3-informational?style=flat-square)

Anna Nginx Helm chart

## Prerequisites

- Kubernetes 1.12+
- Helm 3.0+

## Installing the Chart

To install the chart with the release name `anna-nginx`:

```bash
helm install anna-nginx ./charts/anna-nginx
```

## Uninstalling the Chart

To uninstall the chart with the release name `anna-nginx`:

```bash
helm uninstall anna-nginx
```

## Configuration

The following table lists the configurable parameters of the Anna Nginx chart and their default values.

| Parameter | Description | Default |
|-----------|-------------|---------|
| `image.repository` | The image repository | `quay.io/shesselink81/anna-nginx` |
| `image.tag` | The image tag | `v2.0.9` |
| `image.pullPolicy` | Image pull policy | `IfNotPresent` |
| `replicaCount` | Number of replicas | `1` |
| `service.type` | Service type | `ClusterIP` |
| `service.port` | Service port | `8080` |
| `containerPort` | Container port | `80` |
| `otelCollector.enabled` | Deploy an OpenTelemetry Collector for nginx traces | `true` |
| `otelCollector.image.repository` | OTel Collector image repository | `otel/opentelemetry-collector-contrib` |
| `otelCollector.image.tag` | OTel Collector image tag | `latest` |
| `otelCollector.image.pullPolicy` | OTel Collector image pull policy | `IfNotPresent` |
| `otelCollector.config` | OTel Collector config file contents | see `values.yaml` |

Specify each parameter using the `--set key=value[,key=value]` argument to `helm install`.

Alternatively, a YAML file that specifies the values for the parameters can be provided while installing the chart. For example,

```bash
helm install anna-nginx ./charts/anna-nginx -f values.yaml
```